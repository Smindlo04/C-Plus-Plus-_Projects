#include <iostream>

using namespace std;

//function
void calculateSalary(string arrNames[10], int arrHours[10])
{
    double hWage;

    //input of the function
    cout << "\nEnter the hourly wage: ";
    cin >> hWage;


    //output of the function
    cout << "\n\nEmployees and their salaries" << endl;
    cout << "Name" << "\tHours" << "\tSalary" << endl;


    for(int k = 0; k < 10; k++)
    {
        double salary = hWage*(arrHours[k]);

       cout << arrNames[k] << "\t" << arrHours[k] << "\t" << salary << endl;
    }

}

int main()
{
    string arrNames[10] = {"Smindlo", "Letho", "Siyanda", "Lethu", "Mondli", "Marry", "Ntsako", "Themba", "Gqamu", "Mpume"};
    int arrHours[10] ;


    //input
    for(int k = 0; k < 10; k++)
    {
        cout << "Enter the number of hours for " << arrNames[k]  << ":" ;
        cin >> arrHours[k];


        while(arrHours[k] > 40)
        {
            cout << "Incorrect value for hours worked, please try again" << endl;

            cout << "Enter the number of hours for " << arrNames[k]  << ":" ;
            cin >> arrHours[k];
        }
    }


    //call the function
    calculateSalary(arrNames, arrHours);







    return 0;
}
