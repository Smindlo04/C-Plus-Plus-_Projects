#include <iostream>

using namespace std;

struct Participant
{
    string name;
};

struct Date
{
    int day;
    int month;
    int year;
    int time_mins;
    string gender;
    Participant Pname;
};

void getinfo(Date* myParticipant, int counter)
{
    cin.ignore();
    cout << "Enter name:" ;
    getline(cin, myParticipant[counter].Pname.name);

    cout << "Date of birth: " << endl;
    cout << "Enter day: ";
    cin >> myParticipant[counter].day;

    cout << "Enter month (1 to 12): ";
    cin >> myParticipant[counter].month;

    cout << "Enter year (yyyy): ";
    cin >> myParticipant[counter].year;

    cout << "Enter gender (M/F): ";
    cin >> myParticipant[counter].gender;

    cout << "Enter the time in minutes: ";
    cin >> myParticipant[counter].time_mins;
}

int calculateAge(Date myParticipant[], int counter)
{
    const int THIS_YEAR = 2022;
    int age;

    for(int k = 0; k < counter; k++)
    {
        age = THIS_YEAR - myParticipant[k].year;
    }
    return age;
}

void displayData(Date* myParticipant, int counter)
{
    cout << "List of participants" << endl;
    cout << "Name" << "\t\tGender" << "\t\tBirth year" << "\t\tAge" << "\t\tTime in minutes" << endl;
    int age = calculateAge(myParticipant, counter);

    for(int k = 0; k < counter; k++)
    {
        cout << myParticipant[k].Pname.name << "\t\t" << myParticipant[k].gender << "\t\t" << myParticipant[k].year << "\t\t" << age << "\t\t" << myParticipant[k].time_mins << endl;
    }
}

int findWinner(Date myParticipant[], int counter)
{
    int winner = myParticipant[0].time_mins;
    int index;

    for(int k = 0; k < counter; k++)
    {
        if(myParticipant[k].time_mins < winner)
        {
            winner = myParticipant[k].time_mins;
            index = k;
        }
    }
    return winner;
    return index;
}

void displayWinner(Date* myParticipant, int counter)
{
    int winner = findWinner(myParticipant, counter);
    int age = calculateAge(myParticipant, counter);
    int index = calculateAge(myParticipant, counter);

    cout << "\nWinner of the FunRunEvent" << endl;
    cout << "Name           : " << myParticipant[index].Pname.name << endl;
    cout << "Date of birth  : " << myParticipant[index].day << "-" << myParticipant[index].month << "-" << myParticipant[index].year << endl;
    cout << "Age            : " << age << endl;
    cout << "Time in minutes: " << winner << endl;
}

int main()
{
    int counter = 0;
    int SIZE = 100;
    Date myParticipant[SIZE];
    string answer, gender;

    cout << "Do you want to add a participant? (Y or N): ";
    cin >> answer;

    while(answer != "n" && answer != "N")
    {
        getinfo(myParticipant, counter);
        counter++;

        cout << "\nDo you want to add another participant? (Y or N): ";
        cin >> answer;
    }
    displayData(myParticipant, counter);
    displayWinner(myParticipant, counter);

    return 0;
}
