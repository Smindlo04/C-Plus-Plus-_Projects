#include <iostream>

using namespace std;

void doubleNum(int* pValue)
{
    *pValue *= 2;
    //value = value * 2;
}

int main()
{
    int number = 10;

    cout << "In main, number is " << number << endl;
    cout << "Now calling the doubleNum function" << endl;

    doubleNum(&number);

    cout << "Back in main.  The number is " << number << endl;

    return 0;
}
