#include <iostream>

using namespace std;

int main()
{
    int arrVisitors[6];

    for(int k = 0; k < 6; k++)
    {
        cout << "Enter the number of visitors for day " << (k+1) << ": ";
        cin >> arrVisitors[k];
    }

    cout << "\nList of visitors per day" << endl;

    for(int k = 0; k < 6; k++)
    {
        cout << "Day " << (k+1) << ": " << arrVisitors[k] << endl;
    }

    int lowest = arrVisitors[0];
    int lowest_day = 0;
    int highest = arrVisitors[0];
    int highest_day = 0;

    for(int k = 0; k < 6; k++)
    {
        if(arrVisitors[k] < lowest)
        {
            lowest = arrVisitors[k];
            lowest_day = k;
        }
        if(arrVisitors[k] > highest)
        {
            highest = arrVisitors[k];
            highest_day = k;
        }
    }

    cout << "\nDay with the least number of visitors is day " << (lowest_day + 1) << " with " << lowest << " visitors." << endl;
    cout << "Day with the most number of visitors is day " << (highest_day + 1) << " with " << highest << " visitors." << endl;

    return 0;
}
