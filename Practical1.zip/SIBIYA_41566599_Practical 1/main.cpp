#include <iostream>

using namespace std;

int main()
{   //HEADING
    cout << "\nAssignment 1\n" << endl;

    int yearOfBirth;
    const int thisYear = 2022;

    //INPUT
    cout << "Enter your date of birth (4 digits): ";
    cin >> yearOfBirth;

    //LOOP, PROCESSING AND OUTPUTS
    while((yearOfBirth < 1000) or (yearOfBirth > 9999) or (yearOfBirth >= 2022))
    {
        cout << yearOfBirth << " is invalid. Try again: " ;
        cin >> yearOfBirth;
    }




    if((yearOfBirth % 400 == 0) && (yearOfBirth % 100 == 0))
    {
        cout << yearOfBirth << " was a leap year " << endl;
    }
    else if((yearOfBirth % 4 == 0) && (yearOfBirth % 100 != 0))
    {
        cout << yearOfBirth << " was a leap year " << endl;
    }
    else
    {
        cout << yearOfBirth << " was not a leap year\n" << endl;
    }



    int age= thisYear - yearOfBirth;
    cout << "\nYou are " << age << "  years old" << endl;




    if(yearOfBirth <= 1945)
    {
        cout << "You belong to the Silent Generation." <<endl;
    }
    else if((yearOfBirth >= 1945) && (yearOfBirth <= 1964))
    {
        cout << "You are a Baby Boomer." << endl;
    }
    else if((yearOfBirth >= 1965) && (yearOfBirth <= 1976))
    {
        cout << "You belong to Generation X." << endl;
    }
    else if((yearOfBirth >= 1977) && (yearOfBirth <= 1995))
    {
        cout << "You belong to Generation Y." << endl;
    }
    else if((yearOfBirth >= 1996) && (yearOfBirth <= 2015))
    {
        cout << "You belong to Generation Z." << endl;
    }
    else
    {
        cout << "Your generation is still uncatogarized.\n" << endl;
    }


    //OUTPUT
    cout << "\nDone!\n" << endl;



    return 0;
}
