#include <iostream>
#include <time.h>
#include <iomanip>

using namespace std;

void displayArray(string arrNames[10])
{
    cout << "List of names" << endl;
    for (int k = 0; k < 10; k++)
    {
        cout << (k + 1) << ". "<< arrNames[k] << endl;
    }
}

int findBestProject(string arrPresent[10], int arrMarks[10])
{
    int hiIndex = 0;
    int high = 0;
    cout << "\nNames and marks" << endl;
    for (int k = 0; k < 10; k++)
    {
        cout << (k + 1) << ". " << left << setw(15) <<  arrPresent[k] << arrMarks[k] << endl;
        if (arrMarks[k] > high)
        {
            high = arrMarks[k];
            hiIndex = k;
        }
    }
    return hiIndex;
}

int main()
{
    string arrNames [10] = {"Peter", "Diane", "George", "Frank", "Graig", "Zane", "Jacky", "Mary", "Elizabeth", "Sharon"};
    string arrPresent[10];
    int arrMarks[10];
    int index = 0;
    int newIndex = 0;
    char answer;

    srand(time(0));

    displayArray(arrNames);
    cout << endl;
    for (int k = 0; k < 10; k++)
    {
        do
        {
            index = rand() % 10;
        }
        while (arrNames[index] == "");
        arrPresent[k] = arrNames[index];
        arrNames[index] = "";
    }
    cout << "Order of project presentation" << endl;
    displayArray(arrPresent);

    cout << "\nDo you want to swap names (y or n)? " ;
    cin >> answer;
    while ((toupper(answer)) == 'Y')
    {
        cout << "Enter the number of the name from the list to swap " ;
        cin >> index;
        cout << "Enter the new position for the name from the list " ;
        cin >> newIndex;

        string temp = arrPresent[index -1];
        arrPresent[index -1] = arrPresent[newIndex -1];
        arrPresent[newIndex -1] = temp;
        cout << "\nUpdated list "<< endl;
        displayArray(arrPresent);
        cout << "Do you want to swap more names (y or n)? " ;
        cin >> answer;
    }
    cout << endl;
    for (int k = 0; k < 10; k++)
    {
        cout << "Enter the mark for " << arrPresent[k] << ": ";
        cin >> arrMarks[k];
    }

    index = findBestProject(arrPresent, arrMarks);

    cout << "\nThe student with the highest mark is " << arrPresent[index] << " with a mark of " << arrMarks[index] << endl << endl;

    cout << endl;

    return 0;
}
