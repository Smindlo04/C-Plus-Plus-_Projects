#include <iostream>

using namespace std;

void displayData(int* pArrRain, int* pCounter)
{
    cout << "#Month\t" << "Rainfall figures(mm)" << endl;

    for(int k = 0; k < 12; k++)
    {
        cout << (k + 1) << "\t\t" << *(pArrRain + k) << endl;
    }

}

double calcAve(int* pArrRain, int* pCounter, double* pAve)
{
    const double t_rainfall = 1570.000;

    *pAve = t_rainfall / 12;

    return *pAve;
}

int findHighestRainfall(int* pArrRain, int* pCounter, int* pHighest)
{
    *pHighest = *(pArrRain);

    for(int k = 0; k < *pCounter; k++)
    {
        if(*(pArrRain + k) > *pHighest)
        {
            *pHighest = *(pArrRain + k);
        }
    }
    return *pHighest;
}

int main()
{
    int ArrRain[12] = {234, 325, 287, 112, 16, 0, 0, 0, 45, 123, 224, 204};
    int* pArrRain = ArrRain;

    int counter = 0;
    int* pCounter = &counter;

    double average;
    double* pAve = &average;

    int highest;
    int* pHighest = &highest;

    displayData(pArrRain, pCounter);
    *pAve = calcAve(pArrRain, pCounter, pAve);
    cout << "The average rainfall is " << *pAve << endl;

    *pHighest = findHighestRainfall(ArrRain, pCounter, pHighest);
    cout << "The highest rainfall figure is " << *pHighest << endl;

    return 0;
}
