#include <iostream>


using namespace std;

int main()

{
    cout << "Fun Run Competition" << endl;

    int choice, k = 0, k2 = 0, k3 = 0,registered, largest;
    string participation = " ", cat_= " ";
    const double KM5_FEE = 65.00, KM10_FEE = 100.00, KM15_FEE = 150.00;
    double Income, t_Income, option1, option2, option3;

    cout << "\nDo you want to register a participant (Y or N): ";
    cin >> participation;


    if((participation == "y") || (participation == "Y"))
    {
        cout << "\nCategories: "
         << "\n1. 5 kilometers\n"
         << "2. 10 kilometers\n"
         << "3. 15 kilometers\n";

    cout << "Your choice (1/2/3): ";
    cin >> choice;

    switch(choice)
    {
    case 1:
        Income = KM5_FEE;
        k++;
        option1 = k * Income;
        break;
    case 2:
        Income = KM10_FEE;
        k2++;
        option2 = k2 * Income;
        break;
    case 3:
        Income = KM15_FEE;
        k3++;
        option3 = k3 * Income;
        break;
    default :
        Income = 0 ;
        cout << "Invalid category entered"
             << "\nRegistration cancelled" << endl;
        break;

    }

    }




    else
    {
        cout << "Registration per category" << endl;

        cout << "Category" << "\tNum Athletes"<< "\tIncome"
             << "\n5 kilometers" << "\t\t" << k << "\t" << option1
             << "\n10 kilometers" << "\t\t" << k2 << "\t" << option2
             << "\n15 kilometers" << "\t\t" << k3 << "\t" << option3 << endl;

        registered = k + k2 + k3 ;
        t_Income = option1 + option2 + option3;
        largest = option1;
        if(option1 > largest)
        {
            largest = option1;
            cat_= "5km";

        }
        else if(option2 > largest)
        {
            largest = option2;
            cat_= "10km";

        }
        else
        {
            largest = option3;
            cat_= "15km";
        }
        cout << "\nTotal number of participants: " << registered
             << "\nTotal income: "<< "R" << t_Income
             << "\nCategory with highest income: " << cat_ << endl;

    }





    while((participation == "Y") || (participation == "y"))
    {
        cout << "\nDo you want to register another participant (Y or N): ";
        cin >> participation;
        if((participation == "Y") || (participation == "y"))
        {
             cout << "\nCategories: "
             << "\n1. 5 kilometers\n"
             << "2. 10 kilometers\n"
             << "3. 15 kilometers\n";

             cout << "Your choice (1/2/3): ";
             cin >> choice;

    switch(choice)
    {
    case 1:
        Income = KM5_FEE;
        k++;
        option1 = k * Income;
        break;
    case 2:
        Income = KM10_FEE;
        k++;
        option2 = k2 * Income;
        break;
    case 3:
        Income = KM15_FEE;
        k++;
        option3 = k3 * Income;
        break;
    default :
        Income = 0 ;
        cout << "Invalid category entered"
             << "\nRegistration cancelled" << endl;
        break;

    }

        }


    else
    {
        cout << "Registration per category" << endl;

        cout << "Category" << "\tNum Athletes"<< "\tIncome"
             << "\n5 kilometers" << "\t\t" << k << "\t" << option1
             << "\n10 kilometers" << "\t\t" << k2 << "\t" << option2
             << "\n15 kilometers" << "\t\t" << k3 << "\t" << option3 << endl;

        registered = k + k2 + k3 ;
        t_Income = option1 + option2 + option3;
        largest = option1;
        if(option1 > largest)
        {
            largest = option1;
            cat_= "5km";

        }
        else if(option2 > largest)
        {
            largest = option2;
            cat_= "10km";

        }
        else
        {
            largest = option3;
            cat_= "15km";
        }
        cout << "\nTotal number of participants: " << registered
             << "\nTotal income: "<< "R" << t_Income
             << "\nCategory with highest income: " << cat_ << endl;


    }




    }








    return 0;

}


