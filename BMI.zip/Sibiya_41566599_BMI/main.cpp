#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int choice;
    double BMI = 0, Weight = 0, Height=0;

    string status = "";

    cout << "BMI Calculator\n\n1. Weight in pounds, height in inches\n"
         << "2. Weight in kilograms, height in meters" << endl;

    cin >> choice;

    while((choice != 1) && (choice != 2))
    {
        cout << "Invalid choice; Please enter a valid choice: ";
        cin >> choice;
    }

    if(choice == 1)
    {
    //INPUT - kilograms and meters
        cout << "\nWeight in kilograms?: ";
        cin >> Weight;

        cout << "\nHeight in meters?: ";
        cin >> Height;
    //PROCESSING - Calc BMI
        BMI = (Weight * 703) / (Height * Height);

    //OUTPUT
        printf("\n\nResult.............\n\n Weight: %.2lf kilograms", Weight);
        printf(" Height: %.2lf meters", Height);
        printf(" BMI: %.1lf", BMI);


    }
    else if(choice == 2)
    {
    //INPUT - pounds and inches
        cout << "\nWeight in pounds?: ";
        cin >> Weight;

        cout << "\nHeight in inches?: ";
        cin >> Height;
    //PROCESSING - Calc BMI
        BMI = (Weight * 703) / (Height * Height);

    //OUTPUT
        printf("\n\nResult.............\n\n Weight: %.2lf pounds", Weight);
        printf(" Height: %.2lf inches", Height);
        printf(" BMI: %.1lf", BMI);
    }
    //BMI=21
    if(BMI >= 30) //FALSE
        status = "Obese";
    else if(BMI >= 25) //(BMI <30)
        status = "Overweight";
    else if(BMI >= 18,5) //(BMI <25)
        status = "Normal";
    else
        status = "Underweight";

    cout << "\nStatus: " << status << endl;


    return 0;
}
